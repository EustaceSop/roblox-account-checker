import os
import tkinter as tk
from tkinter import filedialog, messagebox
from colorama import Fore, init

init(autoreset=True)
green, cyan, yellow, reset = Fore.GREEN, Fore.CYAN, Fore.YELLOW, Fore.RESET

def clean_combo():
    # 1. 選擇檔案
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(title="選擇要整理的原始名單", filetypes=[("Text files", "*.txt")])
    
    if not file_path:
        return

    cleaned_list = []
    duplicate_count = 0
    
    print(f"[*] {cyan}正在讀取並整理: {os.path.basename(file_path)}...{reset}")

    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            # 邏輯：只取第一個 "|" 之前的內容，然後取第一個空格之前的內容
            # 這種寫法可以兼容 "email:pass | 剩餘資訊" 或是 "email:pass"
            temp = line.split("|")[0].strip()
            combo = temp.split(" ")[0].strip()

            if ":" in combo:
                if combo not in cleaned_list:
                    cleaned_list.append(combo)
                else:
                    duplicate_count += 1

    # 2. 存檔
    output_path = "cleaned_combos.txt"
    with open(output_path, "w", encoding="utf-8") as f:
        for combo in cleaned_list:
            f.write(combo + "\n")

    print("\n" + "="*30)
    print(f"[*] {green}整理完成！{reset}")
    print(f"[*] 原始帳號總數: {len(cleaned_list) + duplicate_count}")
    print(f"[*] 移除重複數量: {duplicate_count}")
    print(f"[*] 最終有效數量: {green}{len(cleaned_list)}{reset}")
    print(f"[*] 結果已存至: {yellow}{output_path}{reset}")
    print("="*30)
    
    messagebox.showinfo("完成", f"整理完畢！\n有效帳號: {len(cleaned_list)} 個\n已存至: {output_path}")

if __name__ == "__main__":
    clean_combo()