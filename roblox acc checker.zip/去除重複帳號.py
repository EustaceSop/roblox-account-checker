import os
import tkinter as tk
from tkinter import filedialog
from colorama import Fore, init

# 初始化顏色
init(autoreset=True)
cyan = Fore.CYAN
green = Fore.GREEN
yellow = Fore.YELLOW
red = Fore.RED

def remove_duplicates():
    # 隱藏 tkinter 主視窗
    root = tk.Tk()
    root.withdraw()

    print(f"[*] {cyan}請選擇要進行「去重」的帳號名單 (.txt)...")
    file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])

    if not file_path:
        print(f"{red}[!] 未選擇檔案，程式結束。")
        return

    # 讀取檔案並去重
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        total_before = len(lines)
        # 使用 set(集合) 來自動移除重複項，strip() 移除換行符號
        unique_lines = list(dict.fromkeys([line.strip() for line in lines if ":" in line]))
        total_after = len(unique_lines)

        # 存檔
        output_file = "cleaned.txt"
        with open(output_file, 'w', encoding='utf-8') as f:
            for line in unique_lines:
                f.write(line + "\n")

        print(f"\n{green}========================================")
        print(f"[*] 處理完成！")
        print(f"[*] 原始帳號數量: {total_before}")
        print(f"[*] 去重後數量: {total_after}")
        print(f"[*] 移除了 {total_before - total_after} 個重複項")
        print(f"[*] 結果已存入: {output_file}")
        print(f"{green}========================================\n")
        
    except Exception as e:
        print(f"{red}[!] 發生錯誤: {e}")

    input("按 Enter 鍵結束...")

if __name__ == "__main__":
    remove_duplicates()